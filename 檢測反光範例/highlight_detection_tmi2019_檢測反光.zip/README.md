We implemented the following specular highlight detection method using Matlab.
Note that the authors of this paper have not released their code.

```text
@article{li-2019-specul-reflec,
  author = {Li, Ranyang and Pan, Junjun and Si, Yaqing and Yan, Bin and Hu, Yong and Qin, Hong},
  title = {Specular Reflections Removal for Endoscopic Image Sequences With Adaptive-Rpca Decomposition},
  journal = {IEEE Transactions on Medical Imaging},
  volume = {39},
  number = {2},
  pages = {328--340},
  year = {2019},
  tags = {TMI},
}
```
